/**
 * 한글 자모 분해
 * 예: "기타" → ['ㄱ', 'ㅣ', 'ㅌ', 'ㅏ']
 */
function decompose(text: string): string[] {
  const result: string[] = []
  const cho = ['ㄱ', 'ㄲ', 'ㄴ', 'ㄷ', 'ㄸ', 'ㄹ', 'ㅁ', 'ㅂ', 'ㅃ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ']
  const jung = ['ㅏ', 'ㅐ', 'ㅑ', 'ㅒ', 'ㅓ', 'ㅔ', 'ㅕ', 'ㅖ', 'ㅗ', 'ㅘ', 'ㅙ', 'ㅚ', 'ㅝ', 'ㅞ', 'ㅟ', 'ㅢ', 'ㅣ']
  const jong = ['', 'ㄱ', 'ㄲ', 'ㄳ', 'ㄴ', 'ㄵ', 'ㄶ', 'ㄷ', 'ㄹ', 'ㄺ', 'ㄻ', 'ㄼ', 'ㄽ', 'ㄾ', 'ㄿ', 'ㅀ', 'ㅁ', 'ㅂ', 'ㅄ', 'ㅅ', 'ㅆ', 'ㅇ', 'ㅈ', 'ㅉ', 'ㅊ', 'ㅋ', 'ㅌ', 'ㅍ', 'ㅎ']

  for (const char of text) {
    const code = char.charCodeAt(0)
    // 한글 문자인지 확인 (0xAC00 ~ 0xD7A3)
    if (code >= 0xac00 && code <= 0xd7a3) {
      const index = code - 0xac00
      const jongIndex = index % 28
      const jungIndex = Math.floor((index % 588) / 28)
      const choIndex = Math.floor(index / 588)

      result.push(cho[choIndex])
      result.push(jung[jungIndex])
      if (jongIndex > 0) {
        result.push(jong[jongIndex])
      }
    } else {
      result.push(char)
    }
  }

  return result
}

/**
 * 검색어로부터 한글 자모 분해
 * 예: "기" → ['ㄱ', 'ㅣ']
 */
function decomposeQuery(query: string): string[] {
  return decompose(query)
}

/**
 * 텍스트가 검색어를 포함하는지 확인 (자모 분해 기반)
 */
export function matchesKoreanQuery(text: string, query: string): boolean {
  if (!query) return true
  if (!text) return false

  const textDecomposed = decompose(text).join('')
  const queryDecomposed = decomposeQuery(query).join('')

  // 검색어가 텍스트의 분해된 자모에 포함되는지 확인
  return textDecomposed.includes(queryDecomposed)
}

/**
 * 악기 목록에서 검색어로 필터링
 */
export function filterInstrumentsByKoreanQuery<T extends { name: string }>(
  instruments: T[],
  query: string
): T[] {
  if (!query) return instruments

  return instruments.filter((instrument) =>
    matchesKoreanQuery(instrument.name, query)
  )
}
