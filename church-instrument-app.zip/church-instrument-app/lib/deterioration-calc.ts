// 사용기간 점수 계산
export const getUsagePeriodScore = (usagePeriod: number): number => {
  if (usagePeriod > 10) return 2      // 10년 초과
  if (usagePeriod >= 7) return 3      // 7~10년
  if (usagePeriod >= 4) return 4      // 4~6년
  return 5                             // 1~3년
}

// 수리이력 점수 계산
export const getRepairHistoryScore = (repairCount: number): number => {
  if (repairCount >= 3) return 1
  if (repairCount === 2) return 2
  if (repairCount === 1) return 3
  return 5
}

// 주당사용 점수 계산
export const getUsageDegreeScore = (hours: number): number => {
  if (hours >= 4) return 3
  if (hours === 2) return 4
  return 5
}

// 총점과 상태 계산
export const calculateStatus = (
  usagePeriod: number,
  repairCount: number,
  usageHours: number
): { totalScore: number; status: string; color: string } => {
  const usagePeriodScore = getUsagePeriodScore(usagePeriod)
  const repairHistoryScore = getRepairHistoryScore(repairCount)
  const usageDegreeScore = getUsageDegreeScore(usageHours)

  const totalScore = usagePeriodScore + repairHistoryScore + usageDegreeScore

  let status: string
  let color: string

  if (totalScore >= 12) {
    status = '유지'
    color = '#10b981' // 초록색
  } else if (totalScore >= 8) {
    status = '관리'
    color = '#f59e0b' // 노란색
  } else {
    status = '교체'
    color = '#ef4444' // 빨간색
  }

  return { totalScore, status, color }
}

// 계산 상세 정보 생성
export const getCalculationDetails = (
  usagePeriod: number,
  repairCount: number,
  usageHours: number
): string => {
  const usagePeriodScore = getUsagePeriodScore(usagePeriod)
  const repairHistoryScore = getRepairHistoryScore(repairCount)
  const usageDegreeScore = getUsageDegreeScore(usageHours)
  const totalScore = usagePeriodScore + repairHistoryScore + usageDegreeScore

  return `사용기간: ${usagePeriod}년 → ${usagePeriodScore}점
수리이력: ${repairCount}회 → ${repairHistoryScore}점
주당사용: ${usageHours}시간 → ${usageDegreeScore}점
─────────────
총점: ${totalScore}점`
}

// 노후화 상태 계산 (1-5점 기반)
export const calculateDeteriorationStatus = (
  purchaseYearScore: number,
  usagePeriodScore: number,
  usageDegreeScore: number,
  repairHistoryScore: number
): { percentage: number; status: string } => {
  const totalScore = purchaseYearScore + usagePeriodScore + usageDegreeScore + repairHistoryScore
  const percentage = Math.round(((totalScore - 4) / 16) * 100)

  let status: string
  if (percentage >= 80) {
    status = '유지'
  } else if (percentage >= 60) {
    status = '지속관리'
  } else if (percentage >= 40) {
    status = '중간'
  } else if (percentage >= 20) {
    status = '교체준비'
  } else {
    status = '필수교체'
  }

  return { percentage: Math.max(0, Math.min(100, percentage)), status }
}

// 평가 기준 설명
export const evaluationCriteria = {
  usagePeriod: [
    { range: '1~3년', score: 5 },
    { range: '4~6년', score: 4 },
    { range: '7~10년', score: 3 },
    { range: '10년 초과', score: 2 },
  ],
  repairHistory: [
    { range: '0회', score: 5 },
    { range: '1회', score: 3 },
    { range: '2회', score: 2 },
    { range: '3회 이상', score: 1 },
  ],
  usageDegree: [
    { range: '1시간', score: 5 },
    { range: '2시간', score: 4 },
    { range: '4시간 이상', score: 3 },
  ],
  status: [
    { range: '15~12점', status: '유지', color: '#10b981' },
    { range: '11~8점', status: '관리', color: '#f59e0b' },
    { range: '7점 이하', status: '교체', color: '#ef4444' },
  ],
}
