-- 악기 테이블
CREATE TABLE instruments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('타악기', '건반악기', '현악기', '관악기', '그외악기', '음향관련')),
  model TEXT NOT NULL,
  company TEXT NOT NULL,
  purchase_year INTEGER NOT NULL,
  estimated_price NUMERIC NOT NULL,
  usage_period INTEGER NOT NULL,
  installation_location TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 1,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 노후화 점수 테이블
CREATE TABLE deterioration_scores (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  instrument_id UUID NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
  purchase_year_score INTEGER NOT NULL CHECK (purchase_year_score BETWEEN 1 AND 5),
  usage_period_score INTEGER NOT NULL CHECK (usage_period_score BETWEEN 1 AND 5),
  usage_degree_score INTEGER NOT NULL CHECK (usage_degree_score BETWEEN 1 AND 5),
  repair_history_score INTEGER NOT NULL CHECK (repair_history_score BETWEEN 1 AND 5),
  total_percentage INTEGER DEFAULT 0,
  status TEXT DEFAULT 'maintenance' CHECK (status IN ('necessary_replacement', 'prepare_replacement', 'middle', 'continuous_management', 'maintenance')),
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(instrument_id)
);

-- 수리 이력 테이블
CREATE TABLE repair_history (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  instrument_id UUID NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
  repair_date DATE NOT NULL,
  company_name TEXT NOT NULL,
  cost NUMERIC NOT NULL,
  repair_content TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 정기 점검 테이블
CREATE TABLE inspection_schedule (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  instrument_id UUID NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
  scheduled_date DATE NOT NULL,
  completed BOOLEAN DEFAULT FALSE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 악기 이미지 테이블
CREATE TABLE instrument_images (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  instrument_id UUID NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
  image_url TEXT NOT NULL,
  "order" INTEGER CHECK ("order" BETWEEN 1 AND 3),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(instrument_id, "order")
);

-- 인덱스 생성
CREATE INDEX idx_instruments_category ON instruments(category);
CREATE INDEX idx_deterioration_instrument_id ON deterioration_scores(instrument_id);
CREATE INDEX idx_repair_history_instrument_id ON repair_history(instrument_id);
CREATE INDEX idx_repair_history_date ON repair_history(repair_date);
CREATE INDEX idx_inspection_schedule_instrument_id ON inspection_schedule(instrument_id);
CREATE INDEX idx_inspection_schedule_date ON inspection_schedule(scheduled_date);
CREATE INDEX idx_images_instrument_id ON instrument_images(instrument_id);

-- 업데이트 타임스탐프 함수
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 트리거 생성
CREATE TRIGGER update_instruments_updated_at
BEFORE UPDATE ON instruments
FOR EACH ROW
EXECUTE FUNCTION update_updated_at_column();

-- RLS 정책 (공개 접근 허용)
ALTER TABLE instruments ENABLE ROW LEVEL SECURITY;
ALTER TABLE deterioration_scores ENABLE ROW LEVEL SECURITY;
ALTER TABLE repair_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE inspection_schedule ENABLE ROW LEVEL SECURITY;
ALTER TABLE instrument_images ENABLE ROW LEVEL SECURITY;

-- 공개 읽기 정책
CREATE POLICY "Allow public read" ON instruments FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON instruments FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON instruments FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON instruments FOR DELETE USING (true);

CREATE POLICY "Allow public read" ON deterioration_scores FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON deterioration_scores FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON deterioration_scores FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON deterioration_scores FOR DELETE USING (true);

CREATE POLICY "Allow public read" ON repair_history FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON repair_history FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON repair_history FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON repair_history FOR DELETE USING (true);

CREATE POLICY "Allow public read" ON inspection_schedule FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON inspection_schedule FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON inspection_schedule FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON inspection_schedule FOR DELETE USING (true);

CREATE POLICY "Allow public read" ON instrument_images FOR SELECT USING (true);
CREATE POLICY "Allow public insert" ON instrument_images FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public update" ON instrument_images FOR UPDATE USING (true);
CREATE POLICY "Allow public delete" ON instrument_images FOR DELETE USING (true);
