-- Create supplies table for instrument consumables management
CREATE TABLE supplies (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  quantity INTEGER DEFAULT 1,
  unit TEXT NOT NULL,
  last_purchase_date DATE,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS (Row Level Security) - allow public read/write for this app
ALTER TABLE supplies ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Enable read access for all users" ON supplies
  FOR SELECT USING (true);

CREATE POLICY "Enable insert for all users" ON supplies
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable update for all users" ON supplies
  FOR UPDATE USING (true) WITH CHECK (true);

CREATE POLICY "Enable delete for all users" ON supplies
  FOR DELETE USING (true);
