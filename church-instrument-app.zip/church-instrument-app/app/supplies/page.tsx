import SuppliesListPage from '@/components/SuppliesListPage'

export default function SuppliesPage() {
  return <SuppliesListPage />
}
