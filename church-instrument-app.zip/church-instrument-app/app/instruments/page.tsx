import InstrumentListPage from '@/components/InstrumentListPage'

export default function InstrumentsPage() {
  return <InstrumentListPage />
}
