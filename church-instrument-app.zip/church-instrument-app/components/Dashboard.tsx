'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Instrument, DeteriorationScore, statusText, statusColor, RepairHistory } from '@/types'

type StatusCount = {
  maintenance: number
  continuous_management: number
  middle: number
  prepare_replacement: number
  necessary_replacement: number
}

export default function Dashboard() {
  const [instruments, setInstruments] = useState<Instrument[]>([])
  const [deteriorationScores, setDeteriorationScores] = useState<DeteriorationScore[]>([])
  const [repairHistory, setRepairHistory] = useState<RepairHistory[]>([])
  const [statusCounts, setStatusCounts] = useState<StatusCount>({
    maintenance: 0,
    continuous_management: 0,
    middle: 0,
    prepare_replacement: 0,
    necessary_replacement: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchData()
  }, [])

  async function fetchData() {
    try {
      // 악기 데이터
      const { data: instrumentsData } = await supabase
        .from('instruments')
        .select('*')

      // 노후화 점수
      const { data: scoresData } = await supabase
        .from('deterioration_scores')
        .select('*')

      // 최근 수리 이력
      const { data: repairsData } = await supabase
        .from('repair_history')
        .select('*')
        .order('repair_date', { ascending: false })
        .limit(5)

      if (instrumentsData) setInstruments(instrumentsData)
      if (scoresData) {
        setDeteriorationScores(scoresData)
        // 상태별 개수 계산
        const counts = scoresData.reduce(
          (acc, score) => ({
            ...acc,
            [score.status]: (acc[score.status as keyof StatusCount] || 0) + 1,
          }),
          {
            maintenance: 0,
            continuous_management: 0,
            middle: 0,
            prepare_replacement: 0,
            necessary_replacement: 0,
          } as StatusCount
        )
        setStatusCounts(counts)
      }
      if (repairsData) setRepairHistory(repairsData)
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return <div className="p-6 text-center">로딩 중...</div>
  }

  return (
    <div className="p-4 md:p-6 space-y-6">
      {/* 헤더 */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">교회 악기 관리 시스템</h1>
        <p className="text-gray-600">총 악기 수: {instruments.length}대</p>
      </div>

      {/* 상태별 요약 */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {Object.entries(statusText).map(([key, label]) => (
          <div
            key={key}
            className="p-6 rounded-lg text-white text-center"
            style={{ backgroundColor: statusColor[key as keyof typeof statusColor] }}
          >
            <div className="text-3xl font-bold">
              {statusCounts[key as keyof StatusCount]}
            </div>
            <div className="text-xs mt-1">{label}</div>
          </div>
        ))}
      </div>

      {/* 교체 예상 악기 */}
      <div className="bg-gray-800 rounded-lg shadow p-4">
        <h2 className="text-xl font-bold mb-4">교체 예상 악기</h2>
        <div className="space-y-2">
          {deteriorationScores
            .filter((score) =>
              score.status === 'necessary_replacement' ||
              score.status === 'prepare_replacement'
            )
            .map((score) => {
              const instrument = instruments.find((i) => i.id === score.instrument_id)
              if (!instrument) return null
              return (
                <div
                  key={score.id}
                  className="flex justify-between items-center p-3 bg-red-50 border-l-4"
                  style={{ borderColor: statusColor[score.status] }}
                >
                  <div>
                    <div className="font-semibold">{instrument.name}</div>
                    <div className="text-sm text-gray-600">
                      {instrument.model} | {instrument.company}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold" style={{ color: statusColor[score.status] }}>
                      {score.total_percentage}%
                    </div>
                    <div className="text-sm text-gray-600">
                      {statusText[score.status]}
                    </div>
                  </div>
                </div>
              )
            })}
          {deteriorationScores.filter((score) =>
            score.status === 'necessary_replacement' ||
            score.status === 'prepare_replacement'
          ).length === 0 && (
            <div className="text-center py-8 text-gray-500">
              교체 예상 악기가 없습니다
            </div>
          )}
        </div>
      </div>

      {/* 최근 수리 이력 */}
      <div className="bg-gray-800 rounded-lg shadow p-4">
        <h2 className="text-xl font-bold mb-4">최근 수리 이력</h2>
        <div className="space-y-2">
          {repairHistory.map((repair) => {
            const instrument = instruments.find((i) => i.id === repair.instrument_id)
            return (
              <div key={repair.id} className="p-3 border-b last:border-b-0">
                <div className="flex justify-between">
                  <div>
                    <div className="font-semibold">{instrument?.name}</div>
                    <div className="text-sm text-gray-600">
                      {repair.company_name} | {repair.repair_date}
                    </div>
                  </div>
                  <div className="text-right text-sm font-semibold">
                    ₩{repair.cost.toLocaleString()}
                  </div>
                </div>
              </div>
            )
          })}
          {repairHistory.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              수리 이력이 없습니다
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
