'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Instrument, DeteriorationScore, RepairHistory, InstrumentImage } from '@/types'
import { calculateStatus, calculateDeteriorationStatus } from '@/lib/deterioration-calc'
import { statusText, statusColor } from '@/types'
import EvaluationCriteria from '@/components/EvaluationCriteria'

interface InstrumentModalProps {
  instrument: Instrument
  scores?: DeteriorationScore
  onClose: () => void
  onRefresh: () => void
}

export default function InstrumentModal({
  instrument,
  scores,
  onClose,
  onRefresh,
}: InstrumentModalProps) {
  const years = Array.from({ length: 26 }, (_, i) => 2026 - i)

  const companies = ['yamaha', 'nord', 'korg', 'roland', 'pearl', 'tama', 'martin', 'taylor', 'fender', 'efnote', 'vicfirth', 'apple']

  const locations = [
    '사랑부',
    '사랑홀',
    '비전홀',
    '명지본당',
    '새가족실',
    '영아부',
    '유아부',
    '초등1부',
    '초등2부',
    '초등3부',
    '예배학교실',
    '4층홍보실',
    '9층세미나실',
    '하단본당',
    '하단 격실',
    '기타',
  ]

  const [tab, setTab] = useState<'info' | 'scores' | 'repairs' | 'images'>('info')
  const [repairHistory, setRepairHistory] = useState<RepairHistory[]>([])
  const [images, setImages] = useState<InstrumentImage[]>([])
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState(instrument)
  const [scoreData, setScoreData] = useState<{
    purchase_year_score: number
    usage_period_score: number
    usage_degree_score: number
    repair_history_score: number
  }>({
    purchase_year_score: scores?.purchase_year_score || 3,
    usage_period_score: scores?.usage_period_score || 3,
    usage_degree_score: scores?.usage_degree_score || 3,
    repair_history_score: scores?.repair_history_score || 3,
  })
  const [newRepair, setNewRepair] = useState({
    repair_date: new Date().toISOString().split('T')[0],
    company_name: '',
    cost: 0,
    repair_content: '',
  })

  useEffect(() => {
    fetchRelatedData()
  }, [instrument.id])

  async function fetchRelatedData() {
    try {
      const [repairsRes, imagesRes] = await Promise.all([
        supabase
          .from('repair_history')
          .select('*')
          .eq('instrument_id', instrument.id)
          .order('repair_date', { ascending: false }),
        supabase
          .from('instrument_images')
          .select('*')
          .eq('instrument_id', instrument.id)
          .order('order', { ascending: true }),
      ])

      if (repairsRes.data) setRepairHistory(repairsRes.data)
      if (imagesRes.data) setImages(imagesRes.data)
    } catch (error) {
      console.error('Failed to fetch related data:', error)
    }
  }

  async function handleSaveInstrument() {
    try {
      await supabase
        .from('instruments')
        .update(formData)
        .eq('id', instrument.id)

      setIsEditing(false)
      onRefresh()
    } catch (error) {
      console.error('Failed to save instrument:', error)
    }
  }

  async function handleSaveScores() {
    try {
      const { percentage, status } = calculateDeteriorationStatus(
        scoreData.purchase_year_score,
        scoreData.usage_period_score,
        scoreData.usage_degree_score,
        scoreData.repair_history_score
      )

      if (scores) {
        await supabase
          .from('deterioration_scores')
          .update({
            ...scoreData,
            total_percentage: percentage,
            status,
            last_updated: new Date().toISOString(),
          })
          .eq('id', scores.id)
      } else {
        await supabase
          .from('deterioration_scores')
          .insert({
            instrument_id: instrument.id,
            ...scoreData,
            total_percentage: percentage,
            status,
          })
      }

      onRefresh()
    } catch (error) {
      console.error('Failed to save scores:', error)
    }
  }

  async function handleAddRepair() {
    if (!newRepair.company_name || newRepair.cost === 0) {
      alert('필수 정보를 입력해주세요')
      return
    }

    try {
      await supabase
        .from('repair_history')
        .insert({
          instrument_id: instrument.id,
          ...newRepair,
        })

      setNewRepair({
        repair_date: new Date().toISOString().split('T')[0],
        company_name: '',
        cost: 0,
        repair_content: '',
      })

      fetchRelatedData()
    } catch (error) {
      console.error('Failed to add repair:', error)
    }
  }

  async function handleDeleteRepair(repairId: string) {
    if (!confirm('이 수리 기록을 삭제하시겠습니까?')) return

    try {
      await supabase
        .from('repair_history')
        .delete()
        .eq('id', repairId)

      fetchRelatedData()
    } catch (error) {
      console.error('Failed to delete repair:', error)
    }
  }

  const currentScores = scores || {
    total_percentage: 0,
    status: 'maintenance',
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="sticky top-0 bg-gray-700 border-b border-gray-600 p-4 flex justify-between items-start">
          <div>
            <h2 className="text-2xl font-bold text-white">{instrument.name}</h2>
            <p className="text-gray-400 text-sm">
              {instrument.model} | {instrument.company}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-200 text-2xl"
          >
            ✕
          </button>
        </div>

        {/* 탭 */}
        <div className="border-b border-gray-600 flex gap-0 bg-gray-800">
          {['info', 'scores', 'repairs', 'images'].map((tabName) => (
            <button
              key={tabName}
              onClick={() => setTab(tabName as any)}
              className={`flex-1 px-4 py-2 border-b-2 transition-colors ${
                tab === tabName
                  ? 'border-blue-500 text-blue-400 font-semibold'
                  : 'border-transparent text-gray-400 hover:text-gray-300'
              }`}
            >
              {tabName === 'info' && '정보'}
              {tabName === 'scores' && '노후화'}
              {tabName === 'repairs' && '수리이력'}
              {tabName === 'images' && '이미지'}
            </button>
          ))}
        </div>

        {/* 컨텐츠 */}
        <div className="p-6 space-y-4">
          {/* 정보 탭 */}
          {tab === 'info' && (
            <div className="space-y-4">
              {!isEditing ? (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-semibold text-gray-600">악기명</label>
                    <p className="text-lg">{formData.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">카테고리</label>
                    <p className="text-lg">{formData.category}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">품명</label>
                    <p className="text-lg">{formData.model}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">회사명</label>
                    <p className="text-lg">{formData.company}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">구매년도</label>
                    <p className="text-lg">{formData.purchase_year}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">수량</label>
                    <p className="text-lg">{formData.quantity}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">단가예상</label>
                    <p className="text-lg">₩{formData.estimated_price.toLocaleString()}</p>
                  </div>
                  <div>
                    <label className="text-sm font-semibold text-gray-600">사용연도</label>
                    <p className="text-lg">{formData.usage_period}</p>
                  </div>
                  <div className="col-span-2">
                    <label className="text-sm font-semibold text-gray-600">설치위치</label>
                    <p className="text-lg">{formData.installation_location}</p>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="악기명"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="border rounded p-2"
                  />
                  <input
                    type="number"
                    placeholder="수량"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                    className="border rounded p-2"
                  />
                  <input
                    type="text"
                    placeholder="품명"
                    value={formData.model}
                    onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                    className="border rounded p-2 col-span-2"
                  />
                  <select
                    value={formData.company}
                    onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                    className="border rounded p-2 bg-gray-700 text-white"
                  >
                    <option value="">선택</option>
                    {companies.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <select
                    value={formData.purchase_year}
                    onChange={(e) => setFormData({ ...formData, purchase_year: parseInt(e.target.value) })}
                    className="border rounded p-2 bg-gray-700 text-white"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    ))}
                  </select>
                  <select
                    value={formData.usage_period}
                    onChange={(e) => setFormData({ ...formData, usage_period: parseInt(e.target.value) })}
                    className="border rounded p-2 bg-gray-700 text-white"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>
                        {year}
                      </option>
                    ))}
                  </select>
                  <select
                    value={formData.installation_location}
                    onChange={(e) => setFormData({ ...formData, installation_location: e.target.value })}
                    className="border rounded p-2 col-span-2 bg-gray-700 text-white"
                  >
                    <option value="">위치 선택</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>
                        {location}
                      </option>
                    ))}
                  </select>
                  <div className="col-span-2 space-y-2">
                    <label className="block text-sm font-semibold">단가예상 (₩)</label>
                    <input
                      type="range"
                      min="0"
                      max="10000000"
                      step="100000"
                      value={formData.estimated_price}
                      onChange={(e) => setFormData({ ...formData, estimated_price: parseInt(e.target.value) })}
                      className="w-full h-2 bg-gray-600 rounded appearance-none cursor-pointer"
                    />
                    <div className="text-right text-lg font-semibold text-blue-400">
                      ₩{formData.estimated_price.toLocaleString()}
                    </div>
                  </div>
                </div>
              )}
              <div className="pt-4 border-t">
                {isEditing ? (
                  <div className="flex gap-2">
                    <button
                      onClick={handleSaveInstrument}
                      className="flex-1 bg-blue-600 text-white py-3 rounded hover:bg-blue-700 font-semibold"
                    >
                      저장
                    </button>
                    <button
                      onClick={() => setIsEditing(false)}
                      className="flex-1 bg-gray-700 text-gray-300 py-3 rounded hover:bg-gray-600"
                    >
                      취소
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setIsEditing(true)}
                    className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700 font-semibold"
                  >
                    수정
                  </button>
                )}
              </div>
            </div>
          )}

          {/* 노후화 탭 */}
          {tab === 'scores' && (
            <div className="space-y-4">
              {/* 현재 상태 */}
              {scores && (
                (() => {
                  const { totalScore, status, color } = calculateStatus(
                    instrument.usage_period,
                    scores.repair_history_score,
                    scores.usage_degree_score
                  )
                  return (
                    <div className="p-4 rounded-lg" style={{ backgroundColor: color + '20' }}>
                      <div className="text-center">
                        <div className="text-4xl font-bold" style={{ color }}>
                          {totalScore}점
                        </div>
                        <div className="text-lg font-semibold mt-2" style={{ color }}>
                          {status}
                        </div>
                      </div>
                    </div>
                  )
                })()
              )}

              {/* 점수 입력 */}
              <div className="grid grid-cols-2 gap-4">
                {[
                  { key: 'purchase_year_score', label: '구매년도' },
                  { key: 'usage_period_score', label: '사용기간' },
                  { key: 'usage_degree_score', label: '사용 정도' },
                  { key: 'repair_history_score', label: '수리 이력' },
                ].map(({ key, label }) => (
                  <div key={key}>
                    <label className="block text-sm font-semibold mb-2">
                      {label}
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="range"
                        min="1"
                        max="5"
                        value={scoreData[key as keyof typeof scoreData]}
                        onChange={(e) =>
                          setScoreData({
                            ...scoreData,
                            [key]: parseInt(e.target.value),
                          })
                        }
                        className="flex-1"
                      />
                      <span className="font-bold text-lg w-8 text-right">
                        {scoreData[key as keyof typeof scoreData]}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              {/* 평가 기준 */}
              <div className="pt-4 border-t">
                <EvaluationCriteria />
              </div>

              <div className="pt-4">
                <button
                  onClick={handleSaveScores}
                  className="w-full bg-blue-600 text-white py-3 rounded hover:bg-blue-700 font-semibold"
                >
                  저장
                </button>
              </div>
            </div>
          )}

          {/* 수리이력 탭 */}
          {tab === 'repairs' && (
            <div className="space-y-4">
              {/* 새 수리 기록 추가 */}
              <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                <h3 className="font-semibold">수리 기록 추가</h3>
                <input
                  type="date"
                  value={newRepair.repair_date}
                  onChange={(e) => setNewRepair({ ...newRepair, repair_date: e.target.value })}
                  className="w-full border rounded p-2"
                />
                <input
                  type="text"
                  placeholder="수리회사명"
                  value={newRepair.company_name}
                  onChange={(e) => setNewRepair({ ...newRepair, company_name: e.target.value })}
                  className="w-full border rounded p-2"
                />
                <input
                  type="number"
                  placeholder="수리비용"
                  value={newRepair.cost}
                  onChange={(e) => setNewRepair({ ...newRepair, cost: parseInt(e.target.value) })}
                  className="w-full border rounded p-2"
                />
                <input
                  type="text"
                  placeholder="수리 내용 (선택)"
                  value={newRepair.repair_content}
                  onChange={(e) => setNewRepair({ ...newRepair, repair_content: e.target.value })}
                  className="w-full border rounded p-2"
                />
                <button
                  onClick={handleAddRepair}
                  className="w-full bg-green-600 text-white py-3 rounded hover:bg-green-700 font-semibold"
                >
                  추가
                </button>
              </div>

              {/* 수리 기록 목록 */}
              <div className="space-y-2">
                {repairHistory.map((repair) => (
                  <div key={repair.id} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="font-semibold">{repair.company_name}</div>
                        <div className="text-sm text-gray-600">{repair.repair_date}</div>
                        {repair.repair_content && (
                          <div className="text-sm text-gray-700 mt-1">{repair.repair_content}</div>
                        )}
                      </div>
                      <div className="text-right">
                        <div className="font-bold">₩{repair.cost.toLocaleString()}</div>
                        <button
                          onClick={() => handleDeleteRepair(repair.id)}
                          className="text-red-600 text-sm hover:underline mt-1"
                        >
                          삭제
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {repairHistory.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    수리 기록이 없습니다
                  </div>
                )}
              </div>
            </div>
          )}

          {/* 이미지 탭 */}
          {tab === 'images' && (
            <div className="space-y-4">
              <p className="text-sm text-gray-600">최대 3장의 이미지를 업로드할 수 있습니다</p>
              <div className="grid grid-cols-3 gap-4">
                {[1, 2, 3].map((num) => {
                  const image = images.find((img) => img.order === num)
                  return (
                    <div
                      key={num}
                      className="aspect-square border-2 border-dashed rounded-lg p-4 flex items-center justify-center bg-gray-50"
                    >
                      {image ? (
                        <div className="text-center">
                          <img src={image.image_url} alt={`악기 사진 ${num}`} className="w-full h-full object-cover" />
                        </div>
                      ) : (
                        <div className="text-center text-gray-500">
                          <div className="text-3xl mb-2">+</div>
                          <div className="text-sm">사진 {num}</div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
              <p className="text-xs text-gray-500">
                이미지 업로드 기능은 추후 구현될 예정입니다
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
