import { useState, useRef, useEffect } from 'react'

interface StatusBadgeProps {
  status: string
  color: string
  details: string
}

export default function StatusBadge({ status, color, details }: StatusBadgeProps) {
  const [showTooltip, setShowTooltip] = useState(false)
  const [tooltipPos, setTooltipPos] = useState({ top: 0, left: 0 })
  const ref = useRef<HTMLSpanElement>(null)

  const updateTooltipPos = () => {
    if (ref.current) {
      const rect = ref.current.getBoundingClientRect()
      setTooltipPos({
        top: rect.top - 10,
        left: rect.left + rect.width / 2,
      })
    }
  }

  const handleMouseEnter = () => {
    updateTooltipPos()
    setShowTooltip(true)
  }

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation()
    updateTooltipPos()
    setShowTooltip(!showTooltip)
  }

  // 다른 곳을 클릭하면 tooltip 닫기
  useEffect(() => {
    const handleClickOutside = () => setShowTooltip(false)
    if (showTooltip) {
      document.addEventListener('click', handleClickOutside)
      return () => {
        document.removeEventListener('click', handleClickOutside)
      }
    }
    return
  }, [showTooltip])

  return (
    <>
      <span
        ref={ref}
        className="px-2 py-1 rounded text-white text-xs cursor-help inline-block active:opacity-80"
        style={{ backgroundColor: color }}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={() => setShowTooltip(false)}
        onClick={handleClick}
      >
        {status}
      </span>

      {showTooltip && (
        <div
          className="fixed bg-gray-900 text-gray-100 text-xs px-3 py-2 rounded shadow-lg whitespace-nowrap z-50"
          style={{
            top: `${tooltipPos.top}px`,
            left: `${tooltipPos.left}px`,
            transform: 'translate(-50%, -100%)',
            backgroundColor: '#111827',
            border: `1px solid ${color}`,
            fontFamily: 'monospace',
            pointerEvents: 'none',
          }}
        >
          {details.split('\n').map((line, idx) => (
            <div key={idx}>{line}</div>
          ))}
          {/* 화살표 */}
          <div
            style={{
              position: 'absolute',
              top: '100%',
              left: '50%',
              transform: 'translateX(-50%)',
              width: 0,
              height: 0,
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderTop: `6px solid #111827`,
            }}
          ></div>
        </div>
      )}
    </>
  )
}
