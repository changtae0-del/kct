'use client'

import React from 'react'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export default function Navigation() {
  const pathname = usePathname()

  const navItems = [
    { id: 'dashboard', name: '대시보드', href: '/', icon: '📊' },
    { id: 'instruments', name: '악기 리스트', href: '/instruments', icon: '🎵' },
    { id: 'supplies', name: '악기소모품', href: '/supplies', icon: '📦' },
    { id: 'reserved2', name: '예약됨', href: '#', icon: '⚙️' },
  ]

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-gray-800 border-t border-gray-700 shadow-lg md:relative md:bottom-auto md:border-b md:border-t-0">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex justify-around md:justify-start md:gap-1">
          {navItems.map((item) => (
            <Link
              key={item.id}
              href={item.href}
              className={`flex-1 md:flex-none px-4 md:px-6 py-4 text-center md:text-left border-b-4 md:border-b-0 md:border-l-4 transition-colors ${
                pathname === item.href
                  ? 'border-blue-500 text-blue-600 font-semibold'
                  : 'border-transparent text-gray-600 hover:text-blue-600'
              }`}
            >
              <span className="inline-block md:inline">{item.icon} </span>
              <span className="hidden md:inline">{item.name}</span>
              <span className="md:hidden text-xs block">{item.name}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  )
}
