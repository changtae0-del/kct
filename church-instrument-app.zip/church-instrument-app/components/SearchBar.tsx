'use client'

import { useState, useRef, useEffect } from 'react'
import { Instrument } from '@/types'
import { filterInstrumentsByKoreanQuery } from '@/lib/korean-search'

interface SearchBarProps {
  instruments: Instrument[]
  onSelect: (instrument: Instrument) => void
  value: string
  onChange: (value: string) => void
}

export default function SearchBar({ instruments, onSelect, value, onChange }: SearchBarProps) {
  const [showDropdown, setShowDropdown] = useState(false)
  const inputRef = useRef<HTMLInputElement>(null)

  const results = value ? filterInstrumentsByKoreanQuery(instruments, value) : []

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (inputRef.current && !inputRef.current.contains(event.target as Node)) {
        setShowDropdown(false)
      }
    }

    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  return (
    <div className="relative">
      <input
        ref={inputRef}
        type="text"
        placeholder="악기명 검색 (한글/영문)"
        value={value}
        onChange={(e) => {
          onChange(e.target.value)
          setShowDropdown(true)
        }}
        onFocus={() => setShowDropdown(true)}
        className="w-full px-4 py-3 border border-gray-700 bg-gray-700 text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
      />

      {showDropdown && value && (
        <div className="absolute top-full left-0 right-0 bg-gray-800 border border-gray-700 rounded-lg mt-1 shadow-lg z-10">
          {results.length > 0 ? (
            <ul className="max-h-64 overflow-y-auto">
              {results.map((instrument) => (
                <li
                  key={instrument.id}
                  onClick={() => {
                    onSelect(instrument)
                    onChange('')
                    setShowDropdown(false)
                  }}
                  className="px-4 py-3 hover:bg-blue-50 cursor-pointer border-b last:border-b-0"
                >
                  <div className="font-semibold text-sm">{instrument.name}</div>
                  <div className="text-xs text-gray-600">
                    {instrument.model} | {instrument.company}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <div className="px-4 py-3 text-gray-500 text-sm">
              검색 결과가 없습니다
            </div>
          )}
        </div>
      )}
    </div>
  )
}
