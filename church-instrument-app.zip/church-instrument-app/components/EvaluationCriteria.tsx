import { evaluationCriteria } from '@/lib/deterioration-calc'

export default function EvaluationCriteria() {
  return (
    <div className="bg-gray-700 rounded-lg p-4 space-y-4">
      <h3 className="text-sm font-bold text-white mb-3">📋 상태 평가 기준</h3>

      {/* 사용기간 */}
      <div className="border-b border-gray-600 pb-3">
        <p className="text-xs font-semibold text-gray-300 mb-2">사용기간</p>
        <div className="space-y-1">
          {evaluationCriteria.usagePeriod.map((item, idx) => (
            <div key={idx} className="flex justify-between text-xs text-gray-400">
              <span>{item.range}</span>
              <span className="text-blue-400 font-semibold">{item.score}점</span>
            </div>
          ))}
        </div>
      </div>

      {/* 수리이력 */}
      <div className="border-b border-gray-600 pb-3">
        <p className="text-xs font-semibold text-gray-300 mb-2">수리이력</p>
        <div className="space-y-1">
          {evaluationCriteria.repairHistory.map((item, idx) => (
            <div key={idx} className="flex justify-between text-xs text-gray-400">
              <span>{item.range}</span>
              <span className="text-blue-400 font-semibold">{item.score}점</span>
            </div>
          ))}
        </div>
      </div>

      {/* 주당사용 */}
      <div className="border-b border-gray-600 pb-3">
        <p className="text-xs font-semibold text-gray-300 mb-2">주당사용</p>
        <div className="space-y-1">
          {evaluationCriteria.usageDegree.map((item, idx) => (
            <div key={idx} className="flex justify-between text-xs text-gray-400">
              <span>{item.range}</span>
              <span className="text-blue-400 font-semibold">{item.score}점</span>
            </div>
          ))}
        </div>
      </div>

      {/* 상태 판정 */}
      <div>
        <p className="text-xs font-semibold text-gray-300 mb-2">상태 판정</p>
        <div className="space-y-1">
          {evaluationCriteria.status.map((item, idx) => (
            <div key={idx} className="flex justify-between items-center text-xs">
              <span className="text-gray-400">{item.range}</span>
              <span
                className="px-2 py-1 rounded text-white text-xs font-semibold"
                style={{ backgroundColor: item.color }}
              >
                {item.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
