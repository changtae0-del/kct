'use client'

import { useEffect, useState } from 'react'
import * as XLSX from 'xlsx'
import { supabase } from '@/lib/supabase'

interface Supply {
  id: string
  name: string
  category: string
  model: string
  company: string
  purchase_year: number
  estimated_price: number
  usage_period: number
  installation_location: string
  quantity: number
}

export default function SuppliesListPage() {
  const [supplies, setSupplies] = useState<Supply[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [sortField, setSortField] = useState<string | null>('installation_location')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  const [lastUpdateTime, setLastUpdateTime] = useState<Date>(new Date())
  const [currentTime, setCurrentTime] = useState<Date>(new Date())
  const [newSupply, setNewSupply] = useState({
    name: '',
    category: '타악기' as const,
    model: '',
    company: '',
    purchase_year: new Date().getFullYear(),
    estimated_price: 0,
    usage_period: 0,
    installation_location: '',
    quantity: 1,
  })

  const categories = ['타악기', '건반악기', '현악기', '관악기', '그외악기', '음향관련']
  const years = Array.from({ length: 26 }, (_, i) => 2026 - i)
  const companies = ['no', 'yamaha', 'nord', 'korg', 'roland', 'pearl', 'tama', 'martin', 'taylor', 'fender', 'efnote', 'vicfirth', 'apple', 'kuzwail', '질전', '사비안', '보스포러스', '메이늘']
  const locations = ['0 비전홀', '1 사랑홀', '1 사랑부', '2 명지본당', '2 새가족실', '2 영아부', '4 예배학교실', '4 홍보실', '4 유아부', '5 유치부', '6 초등1부', '8 초등2부', '9 세미나', '10 초등3부', '11 인디', '하단본당', '하단 격실', '기타']

  // 설치 위치별 배경색
  const locationColors: { [key: string]: string } = {
    '0 비전홀': 'bg-purple-900/30',
    '1 사랑홀': 'bg-blue-900/30',
    '1 사랑부': 'bg-blue-950/30',
    '2 명지본당': 'bg-yellow-900/30',
    '2 새가족실': 'bg-green-900/30',
    '2 영아부': 'bg-pink-900/30',
    '4 예배학교실': 'bg-cyan-900/30',
    '4 홍보실': 'bg-teal-900/30',
    '4 유아부': 'bg-rose-900/30',
    '5 유치부': 'bg-fuchsia-900/30',
    '6 초등1부': 'bg-orange-900/30',
    '8 초등2부': 'bg-amber-900/30',
    '9 세미나': 'bg-indigo-900/30',
    '10 초등3부': 'bg-yellow-800/30',
    '11 인디': 'bg-violet-900/30',
    '하단본당': 'bg-red-900/30',
    '하단 격실': 'bg-red-800/30',
    '기타': 'bg-gray-700/30',
  }

  const calculateUsagePeriod = (purchaseYear: number) => {
    const today = new Date()
    const currentYear = today.getFullYear()
    const currentMonth = today.getMonth()
    const currentDay = today.getDate()

    let basePeriod = currentYear - purchaseYear
    const decimalPart = (currentMonth + currentDay / 30) / 12
    const totalPeriod = basePeriod + decimalPart

    return Math.max(0, Math.round(totalPeriod))
  }

  useEffect(() => {
    fetchData()
  }, [])

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  async function fetchData() {
    try {
      const { data: suppliesData } = await supabase
        .from('supplies')
        .select('*')
        .order('installation_location', { ascending: true })

      if (suppliesData) setSupplies(suppliesData)
      setLastUpdateTime(new Date())
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleQuantityUpdate(supplyId: string, quantity: number) {
    try {
      await supabase
        .from('supplies')
        .update({ quantity })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update quantity:', error)
    }
  }

  async function handleLocationUpdate(supplyId: string, location: string) {
    try {
      await supabase
        .from('supplies')
        .update({ installation_location: location })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update location:', error)
    }
  }

  async function handleNameUpdate(supplyId: string, name: string) {
    try {
      await supabase
        .from('supplies')
        .update({ name })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update name:', error)
    }
  }

  async function handleCategoryUpdate(supplyId: string, category: string) {
    try {
      await supabase
        .from('supplies')
        .update({ category })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update category:', error)
    }
  }

  async function handleCompanyUpdate(supplyId: string, company: string) {
    try {
      await supabase
        .from('supplies')
        .update({ company })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update company:', error)
    }
  }

  async function handleModelUpdate(supplyId: string, model: string) {
    try {
      await supabase
        .from('supplies')
        .update({ model })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update model:', error)
    }
  }

  async function handlePurchaseYearUpdate(supplyId: string, purchaseYear: number) {
    try {
      const usagePeriod = calculateUsagePeriod(purchaseYear)
      await supabase
        .from('supplies')
        .update({ purchase_year: purchaseYear, usage_period: usagePeriod })
        .eq('id', supplyId)

      fetchData()
    } catch (error) {
      console.error('Failed to update purchase year:', error)
    }
  }

  async function handleAddNewSupply() {
    try {
      await supabase
        .from('supplies')
        .insert([newSupply])

      setNewSupply({
        name: '',
        category: '타악기',
        model: '',
        company: '',
        purchase_year: new Date().getFullYear(),
        estimated_price: 0,
        usage_period: 0,
        installation_location: '',
        quantity: 1,
      })
      setIsAddingNew(false)
      fetchData()
    } catch (error) {
      console.error('Failed to add supply:', error)
      alert('소모품 추가에 실패했습니다')
    }
  }

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortOrder('asc')
    }
  }

  const exportToExcel = () => {
    const headers = ['소모품명', '카테고리', '회사', '구매예상', '사용기간', '설치위치', '수량']

    const data = filteredSupplies.map((supply) => ({
      '소모품명': supply.name,
      '카테고리': supply.category,
      '회사': supply.company || '-',
      '구매예상': supply.purchase_year,
      '사용기간': supply.usage_period + '년',
      '설치위치': supply.installation_location,
      '수량': supply.quantity,
    }))

    const worksheet = XLSX.utils.json_to_sheet(data)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, '소모품')

    const fileName = `소모품_${new Date().toISOString().split('T')[0]}.xlsx`
    XLSX.writeFile(workbook, fileName)
  }

  let filteredSupplies = supplies.filter((supply) => {
    if (searchQuery && !supply.name.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !supply.category.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false
    }
    if (selectedCategory && supply.category !== selectedCategory) return false
    return true
  })

  if (sortField) {
    filteredSupplies.sort((a, b) => {
      let aValue: any = a[sortField as keyof Supply]
      let bValue: any = b[sortField as keyof Supply]

      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase()
        bValue = (bValue as string).toLowerCase()
      }

      if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1
      if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1
      return 0
    })
  }

  if (loading) {
    return <div className="p-6 text-center">로딩 중...</div>
  }

  return (
    <div className="py-4 md:py-6 space-y-6">
      <div className="mb-8 flex justify-between items-start" style={{ marginLeft: '100px', marginRight: '100px' }}>
        <div>
          <div className="mb-6">
            <h1 className="text-3xl font-bold">악기소모품 관리 <span className="text-sm font-normal text-gray-400">(made by kct)</span></h1>
            <div className="text-xs text-gray-500 mt-2">
              <p>현재 시간: {currentTime.toLocaleTimeString('ko-KR')}</p>
              <p>최근 업데이트: {lastUpdateTime.toLocaleString('ko-KR')}</p>
            </div>
          </div>
          <div className="text-sm text-gray-300">
            <p className="font-semibold text-white">
              전체: {filteredSupplies.length}개
              {categories.map((cat) => {
                const count = filteredSupplies.filter((i) => i.category === cat).length
                return (
                  <span key={cat} className="ml-4">
                    | {cat}: <span className="text-blue-400 font-semibold">{count}개</span>
                  </span>
                )
              })}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportToExcel}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold text-xs"
          >
            📊 Excel 내보내기
          </button>
          <button
            onClick={() => setIsAddingNew(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold text-xs"
          >
            + 새 소모품 추가
          </button>
        </div>
      </div>

      {/* 검색 바 */}
      <div style={{ marginLeft: '100px', marginRight: '100px' }}>
        <input
          type="text"
          placeholder="소모품명 또는 카테고리로 검색..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>

      {/* 카테고리 필터 */}
      <div className="space-y-3" style={{ marginLeft: '100px', marginRight: '100px' }}>
        <div>
          <label className="block text-sm font-semibold mb-2">카테고리</label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1.5 rounded text-xs ${
                selectedCategory === null
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              전체
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1.5 rounded text-xs ${
                  selectedCategory === category
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 소모품 테이블 */}
      <div className="bg-gray-800 rounded-lg shadow overflow-x-auto" style={{ margin: '0 100px 100px 100px' }}>
        <table className="w-full">
          <thead className="bg-gray-700 sticky top-0 z-10">
            <tr>
              <th
                onClick={() => handleSort('installation_location')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                설치위치 <span className={sortField === 'installation_location' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'installation_location' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('name')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                소모품명 <span className={sortField === 'name' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'name' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('category')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                카테고리 <span className={sortField === 'category' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'category' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('company')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                회사 <span className={sortField === 'company' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'company' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('purchase_year')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                구매예상 <span className={sortField === 'purchase_year' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'purchase_year' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('usage_period')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                사용기간 <span className={sortField === 'usage_period' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'usage_period' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('quantity')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                수량 <span className={sortField === 'quantity' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'quantity' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th className="px-4 py-2 text-left text-sm font-semibold">액션</th>
            </tr>
          </thead>
          <tbody>
            {isAddingNew && (
              <tr className="border-t border-gray-700 bg-emerald-900 bg-opacity-30">
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newSupply.installation_location}
                    onChange={(e) => setNewSupply({ ...newSupply, installation_location: e.target.value })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    <option value="">선택</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <input
                    type="text"
                    placeholder="소모품명 *"
                    value={newSupply.name}
                    onChange={(e) => setNewSupply({ ...newSupply, name: e.target.value })}
                    className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  />
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newSupply.category}
                    onChange={(e) => setNewSupply({ ...newSupply, category: e.target.value as any })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newSupply.company}
                    onChange={(e) => setNewSupply({ ...newSupply, company: e.target.value })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    <option value="">선택 *</option>
                    {companies.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newSupply.purchase_year}
                    onChange={(e) => {
                      const year = parseInt(e.target.value)
                      setNewSupply({
                        ...newSupply,
                        purchase_year: year,
                        usage_period: calculateUsagePeriod(year)
                      })
                    }}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </td>
                <td colSpan={2} className="px-4 py-2 text-sm"></td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newSupply.quantity}
                    onChange={(e) => setNewSupply({ ...newSupply, quantity: parseInt(e.target.value) })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <div className="flex gap-2">
                    <button
                      onClick={handleAddNewSupply}
                      className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-xs"
                    >
                      저장
                    </button>
                    <button
                      onClick={() => setIsAddingNew(false)}
                      className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-1 rounded text-xs"
                    >
                      취소
                    </button>
                  </div>
                </td>
              </tr>
            )}
            {filteredSupplies.map((supply) => (
              <tr key={supply.id} className={`border-t border-gray-700 hover:bg-emerald-900 text-gray-100 ${locationColors[supply.installation_location] || ''}`}>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={supply.installation_location}
                    onChange={(e) => handleLocationUpdate(supply.id, e.target.value)}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    <option value="">선택</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <input
                    type="text"
                    value={supply.name}
                    onChange={(e) => handleNameUpdate(supply.id, e.target.value)}
                    className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  />
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={supply.category}
                    onChange={(e) => handleCategoryUpdate(supply.id, e.target.value)}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={supply.company}
                    onChange={(e) => handleCompanyUpdate(supply.id, e.target.value)}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    <option value="">선택</option>
                    {companies.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={supply.purchase_year}
                    onChange={(e) => handlePurchaseYearUpdate(supply.id, parseInt(e.target.value))}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  {supply.usage_period}년
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={supply.quantity}
                    onChange={(e) => handleQuantityUpdate(supply.id, parseInt(e.target.value))}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs w-full"
                  >
                    {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <button
                    onClick={() => {}}
                    className="text-blue-600 hover:underline"
                  >
                    상세
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {filteredSupplies.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            일치하는 소모품이 없습니다
          </div>
        )}
      </div>
    </div>
  )
}
