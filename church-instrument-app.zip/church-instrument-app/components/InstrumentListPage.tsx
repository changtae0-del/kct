'use client'

import { useEffect, useState } from 'react'
import * as XLSX from 'xlsx'
import { supabase } from '@/lib/supabase'
import { Instrument, DeteriorationScore, statusText, statusColor } from '@/types'
import { filterInstrumentsByKoreanQuery } from '@/lib/korean-search'
import { calculateStatus, getCalculationDetails } from '@/lib/deterioration-calc'
import SearchBar from '@/components/SearchBar'
import InstrumentModal from '@/components/InstrumentModal'
import AddInstrumentModal from '@/components/AddInstrumentModal'
import StatusBadge from '@/components/StatusBadge'
import RepairHistoryModal from '@/components/RepairHistoryModal'

interface RepairHistory {
  id: string
  instrument_id: string
  repair_date: string
  company_name: string
  cost: number
  repair_content: string
  created_at: string
}

export default function InstrumentListPage() {
  const [instruments, setInstruments] = useState<Instrument[]>([])
  const [deteriorationScores, setDeteriorationScores] = useState<DeteriorationScore[]>([])
  const [repairHistories, setRepairHistories] = useState<RepairHistory[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedStatus, setSelectedStatus] = useState<string | null>(null)
  const [selectedInstrument, setSelectedInstrument] = useState<Instrument | null>(null)
  const [selectedInstrumentForRepair, setSelectedInstrumentForRepair] = useState<string | null>(null)
  const [showRepairModal, setShowRepairModal] = useState(false)
  const [showAddModal, setShowAddModal] = useState(false)
  const [loading, setLoading] = useState(true)
  const [isAddingNew, setIsAddingNew] = useState(false)
  const [sortField, setSortField] = useState<string | null>('installation_location')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc')
  const [lastUpdateTime, setLastUpdateTime] = useState<Date>(new Date())
  const [currentTime, setCurrentTime] = useState<Date>(new Date())
  const [newInstrument, setNewInstrument] = useState({
    name: '',
    category: '타악기' as const,
    model: '',
    company: '',
    purchase_year: new Date().getFullYear(),
    estimated_price: 0,
    usage_period: 0,
    installation_location: '',
    quantity: 1,
  })

  const categories = ['타악기', '건반악기', '현악기', '관악기', '그외악기', '음향관련']
  const statuses = ['maintenance', 'continuous_management', 'middle', 'prepare_replacement', 'necessary_replacement']
  const years = Array.from({ length: 26 }, (_, i) => 2026 - i)
  const companies = ['no', 'yamaha', 'nord', 'korg', 'roland', 'pearl', 'tama', 'martin', 'taylor', 'fender', 'efnote', 'vicfirth', 'apple', 'kuzwail']
  const locations = ['0 비전홀', '1 사랑홀', '1 사랑부', '2 명지본당', '2 새가족실', '2 영아부', '4 예배학교실', '4 홍보실', '4 유아부', '5 유치부', '6 초등1부', '8 초등2부', '9 세미나', '10 초등3부', '11 인디', '하단본당', '하단 격실', '기타']

  // 설치 위치별 배경색
  const locationColors: { [key: string]: string } = {
    '0 비전홀': 'bg-purple-900/30',
    '1 사랑홀': 'bg-blue-900/30',
    '1 사랑부': 'bg-blue-950/30',
    '2 명지본당': 'bg-yellow-900/30',
    '2 새가족실': 'bg-green-900/30',
    '2 영아부': 'bg-pink-900/30',
    '4 예배학교실': 'bg-cyan-900/30',
    '4 홍보실': 'bg-teal-900/30',
    '4 유아부': 'bg-rose-900/30',
    '5 유치부': 'bg-fuchsia-900/30',
    '6 초등1부': 'bg-orange-900/30',
    '8 초등2부': 'bg-amber-900/30',
    '9 세미나': 'bg-indigo-900/30',
    '10 초등3부': 'bg-yellow-800/30',
    '11 인디': 'bg-violet-900/30',
    '하단본당': 'bg-red-900/30',
    '하단 격실': 'bg-red-800/30',
    '기타': 'bg-gray-700/30',
  }

  const calculateUsagePeriod = (purchaseYear: number) => {
    const today = new Date()
    const currentYear = today.getFullYear()
    const currentMonth = today.getMonth() // 0-11
    const currentDay = today.getDate() // 1-31

    let basePeriod = currentYear - purchaseYear

    // 현재 월/일을 고려한 소수점 추가
    const decimalPart = (currentMonth + currentDay / 30) / 12
    const totalPeriod = basePeriod + decimalPart

    return Math.max(0, Math.round(totalPeriod))
  }

  useEffect(() => {
    fetchData()
  }, [])

  // 실시간 시계 업데이트
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  async function fetchData() {
    try {
      const { data: instrumentsData } = await supabase
        .from('instruments')
        .select('*')
        .order('installation_location', { ascending: true })

      const { data: scoresData } = await supabase
        .from('deterioration_scores')
        .select('*')

      const { data: repairsData } = await supabase
        .from('repair_history')
        .select('*')
        .order('repair_date', { ascending: false })

      if (instrumentsData) setInstruments(instrumentsData)
      if (scoresData) setDeteriorationScores(scoresData)
      if (repairsData) setRepairHistories(repairsData)
      setLastUpdateTime(new Date())
    } catch (error) {
      console.error('Failed to fetch data:', error)
    } finally {
      setLoading(false)
    }
  }

  async function handleScoreUpdate(instrumentId: string, scoreField: string, value: number) {
    try {
      const score = deteriorationScores.find((s) => s.instrument_id === instrumentId)

      if (score) {
        await supabase
          .from('deterioration_scores')
          .update({
            [scoreField]: value,
            last_updated: new Date().toISOString(),
          })
          .eq('id', score.id)
      } else {
        const newScore: any = {
          instrument_id: instrumentId,
          purchase_year_score: 3,
          usage_period_score: 3,
          usage_degree_score: 3,
          repair_history_score: 3,
        }
        newScore[scoreField] = value
        await supabase
          .from('deterioration_scores')
          .insert(newScore)
      }

      fetchData()
    } catch (error) {
      console.error('Failed to update score:', error)
    }
  }

  async function handleQuantityUpdate(instrumentId: string, quantity: number) {
    try {
      await supabase
        .from('instruments')
        .update({ quantity })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update quantity:', error)
    }
  }

  async function handleLocationUpdate(instrumentId: string, location: string) {
    try {
      await supabase
        .from('instruments')
        .update({ installation_location: location })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update location:', error)
    }
  }

  async function handleNameUpdate(instrumentId: string, name: string) {
    try {
      await supabase
        .from('instruments')
        .update({ name })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update name:', error)
    }
  }

  async function handleCategoryUpdate(instrumentId: string, category: string) {
    try {
      await supabase
        .from('instruments')
        .update({ category })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update category:', error)
    }
  }

  async function handleCompanyUpdate(instrumentId: string, company: string) {
    try {
      await supabase
        .from('instruments')
        .update({ company })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update company:', error)
    }
  }

  async function handleModelUpdate(instrumentId: string, model: string) {
    try {
      await supabase
        .from('instruments')
        .update({ model })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update model:', error)
    }
  }

  async function handlePurchaseYearUpdate(instrumentId: string, purchaseYear: number) {
    try {
      const usagePeriod = calculateUsagePeriod(purchaseYear)
      await supabase
        .from('instruments')
        .update({ purchase_year: purchaseYear, usage_period: usagePeriod })
        .eq('id', instrumentId)

      fetchData()
    } catch (error) {
      console.error('Failed to update purchase year:', error)
    }
  }

  async function handleAddNewInstrument() {
    try {
      await supabase
        .from('instruments')
        .insert([newInstrument])

      setNewInstrument({
        name: '',
        category: '타악기',
        model: '',
        company: '',
        purchase_year: new Date().getFullYear(),
        estimated_price: 0,
        usage_period: 0,
        installation_location: '',
        quantity: 1,
      })
      setIsAddingNew(false)
      fetchData()
    } catch (error) {
      console.error('Failed to add instrument:', error)
      alert('악기 추가에 실패했습니다')
    }
  }

  const handleSort = (field: string) => {
    if (sortField === field) {
      // 같은 필드 클릭 시 정렬 순서 반전
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      // 다른 필드 클릭 시 오름차순으로 정렬
      setSortField(field)
      setSortOrder('asc')
    }
  }

  const exportToExcel = () => {
    // 헤더
    const headers = ['악기명', '카테고리', '회사', '구매예상', '사용기간', '주당사용', '수리이력', '설치위치', '수량', '상태']

    // 데이터
    const data = filteredInstruments.map((instrument) => {
      const score = deteriorationScores.find((s) => s.instrument_id === instrument.id)
      return {
        '악기명': instrument.name,
        '카테고리': instrument.category,
        '회사': instrument.company || '-',
        '구매예상': instrument.purchase_year,
        '사용기간': instrument.usage_period + '년',
        '주당사용': score?.usage_degree_score || '-',
        '수리이력': score?.repair_history_score || '-',
        '설치위치': instrument.installation_location,
        '수량': instrument.quantity,
        '상태': score?.status ? statusText[score.status as keyof typeof statusText] : '-'
      }
    })

    // Excel 워크북 생성
    const worksheet = XLSX.utils.json_to_sheet(data)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, '악기목록')

    // 다운로드
    const fileName = `악기목록_${new Date().toISOString().split('T')[0]}.xlsx`
    XLSX.writeFile(workbook, fileName)
  }

  let filteredInstruments = filterInstrumentsByKoreanQuery(instruments, searchQuery)
    .filter((instrument) => !selectedCategory || instrument.category === selectedCategory)
    .filter((instrument) => {
      if (!selectedStatus) return true
      const score = deteriorationScores.find((s) => s.instrument_id === instrument.id)
      return score?.status === selectedStatus
    })

  // 정렬 적용
  if (sortField) {
    filteredInstruments.sort((a, b) => {
      let aValue: any = a[sortField as keyof Instrument]
      let bValue: any = b[sortField as keyof Instrument]

      if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase()
        bValue = (bValue as string).toLowerCase()
      }

      if (aValue < bValue) return sortOrder === 'asc' ? -1 : 1
      if (aValue > bValue) return sortOrder === 'asc' ? 1 : -1
      return 0
    })
  }

  if (loading) {
    return <div className="p-6 text-center">로딩 중...</div>
  }

  return (
    <div className="py-4 md:py-6 space-y-6">
      <div className="mb-8 flex justify-between items-start" style={{ marginLeft: '100px', marginRight: '100px' }}>
        <div>
          <div className="mb-6">
            <h1 className="text-3xl font-bold">호산나교회 악기관리리스트 <span className="text-sm font-normal text-gray-400">(made by kct)</span></h1>
            <div className="text-xs text-gray-500 mt-2">
              <p>현재 시간: {currentTime.toLocaleTimeString('ko-KR')}</p>
              <p>최근 업데이트: {lastUpdateTime.toLocaleString('ko-KR')}</p>
            </div>
          </div>
          <div className="text-sm text-gray-300">
            <p className="font-semibold text-white">
              전체: {filteredInstruments.length}대
              {categories.map((cat) => {
                const count = filteredInstruments.filter((i) => i.category === cat).length
                return (
                  <span key={cat} className="ml-4">
                    | {cat}: <span className="text-blue-400 font-semibold">{count}대</span>
                  </span>
                )
              })}
            </p>
          </div>
        </div>
        <div className="flex gap-2">
          <button
            onClick={exportToExcel}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-lg font-semibold text-xs"
          >
            📊 Excel 내보내기
          </button>
          <button
            onClick={() => setIsAddingNew(true)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-semibold text-xs"
          >
            + 새 악기 추가
          </button>
        </div>
      </div>

      {/* 검색 바 */}
      <div style={{ marginLeft: '100px', marginRight: '100px' }}>
        <SearchBar
          instruments={instruments}
          onSelect={(instrument) => setSelectedInstrument(instrument)}
          value={searchQuery}
          onChange={setSearchQuery}
        />
      </div>

      {/* 필터 */}
      <div className="space-y-3" style={{ marginLeft: '100px', marginRight: '100px' }}>
        {/* 카테고리 필터 */}
        <div>
          <label className="block text-sm font-semibold mb-2">카테고리</label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedCategory(null)}
              className={`px-3 py-1.5 rounded text-xs ${
                selectedCategory === null
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              전체
            </button>
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-3 py-1.5 rounded text-xs ${
                  selectedCategory === category
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-200 text-gray-700'
                }`}
              >
                {category}
              </button>
            ))}
          </div>
        </div>

        {/* 상태 필터 */}
        <div>
          <label className="block text-sm font-semibold mb-2">상태</label>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => setSelectedStatus(null)}
              className={`px-3 py-1.5 rounded text-xs ${
                selectedStatus === null
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              전체
            </button>
            {statuses.map((status) => (
              <button
                key={status}
                onClick={() => setSelectedStatus(status)}
                className="px-3 py-1.5 rounded text-xs text-white"
                style={{
                  backgroundColor:
                    selectedStatus === status
                      ? statusColor[status as keyof typeof statusColor]
                      : '#d1d5db',
                }}
              >
                {statusText[status as keyof typeof statusText]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* 악기 테이블 */}
      <div className="bg-gray-800 rounded-lg shadow overflow-x-auto" style={{ margin: '0 100px 100px 100px' }}>
        <table className="w-full">
          <thead className="bg-gray-700 sticky top-0 z-10">
            <tr>
              <th
                onClick={() => handleSort('installation_location')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                설치위치 <span className={sortField === 'installation_location' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'installation_location' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('name')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                악기명 <span className={sortField === 'name' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'name' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('category')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                카테고리 <span className={sortField === 'category' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'category' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('company')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                회사 <span className={sortField === 'company' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'company' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('purchase_year')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                구매예상 <span className={sortField === 'purchase_year' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'purchase_year' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th
                onClick={() => handleSort('usage_period')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                사용기간 <span className={sortField === 'usage_period' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'usage_period' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th className="px-4 py-2 text-left text-sm font-semibold">주당사용</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">수리이력</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">수리내역</th>
              <th
                onClick={() => handleSort('quantity')}
                className="px-4 py-2 text-left text-sm font-semibold cursor-pointer hover:bg-gray-600 select-none"
              >
                수량 <span className={sortField === 'quantity' ? 'text-yellow-400' : 'text-gray-500'}>{sortField === 'quantity' ? (sortOrder === 'asc' ? '▲' : '▼') : '⇅'}</span>
              </th>
              <th className="px-4 py-2 text-left text-sm font-semibold">상태</th>
              <th className="px-4 py-2 text-left text-sm font-semibold">액션</th>
            </tr>
          </thead>
          <tbody>
            {isAddingNew && (
              <tr className="border-t border-gray-700 bg-emerald-900 bg-opacity-30">
                <td className="px-4 py-2 text-sm">
                  <input
                    type="text"
                    placeholder="악기명 *"
                    value={newInstrument.name}
                    onChange={(e) => setNewInstrument({ ...newInstrument, name: e.target.value })}
                    className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  />
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newInstrument.category}
                    onChange={(e) => setNewInstrument({ ...newInstrument, category: e.target.value as any })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>{cat}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newInstrument.company}
                    onChange={(e) => setNewInstrument({ ...newInstrument, company: e.target.value })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  >
                    <option value="">선택 *</option>
                    {companies.map((c) => (
                      <option key={c} value={c}>{c}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newInstrument.purchase_year}
                    onChange={(e) => {
                      const year = parseInt(e.target.value)
                      setNewInstrument({
                        ...newInstrument,
                        purchase_year: year,
                        usage_period: calculateUsagePeriod(year)
                      })
                    }}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  >
                    {years.map((year) => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                </td>
                <td colSpan={4} className="px-4 py-2 text-sm"></td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newInstrument.installation_location}
                    onChange={(e) => setNewInstrument({ ...newInstrument, installation_location: e.target.value })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  >
                    <option value="">선택</option>
                    {locations.map((location) => (
                      <option key={location} value={location}>{location}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm">
                  <select
                    value={newInstrument.quantity}
                    onChange={(e) => setNewInstrument({ ...newInstrument, quantity: parseInt(e.target.value) })}
                    className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                  >
                    {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (
                      <option key={n} value={n}>{n}</option>
                    ))}
                  </select>
                </td>
                <td className="px-4 py-2 text-sm"></td>
                <td className="px-4 py-2 text-sm">
                  <div className="flex gap-2">
                    <button
                      onClick={handleAddNewInstrument}
                      className="bg-green-600 hover:bg-green-700 text-white px-3 py-1 rounded text-xs"
                    >
                      저장
                    </button>
                    <button
                      onClick={() => setIsAddingNew(false)}
                      className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-1 rounded text-xs"
                    >
                      취소
                    </button>
                  </div>
                </td>
              </tr>
            )}
            {filteredInstruments.map((instrument) => {
              const score = deteriorationScores.find((s) => s.instrument_id === instrument.id)
              return (
                <tr key={instrument.id} className={`border-t border-gray-700 hover:bg-emerald-900 text-gray-100 ${locationColors[instrument.installation_location] || ''}`}>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={instrument.installation_location}
                      onChange={(e) => handleLocationUpdate(instrument.id, e.target.value)}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      <option value="">선택</option>
                      {locations.map((location) => (
                        <option key={location} value={location}>{location}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <input
                      type="text"
                      value={instrument.name}
                      onChange={(e) => handleNameUpdate(instrument.id, e.target.value)}
                      className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    />
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={instrument.category}
                      onChange={(e) => handleCategoryUpdate(instrument.id, e.target.value)}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={instrument.company}
                      onChange={(e) => handleCompanyUpdate(instrument.id, e.target.value)}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      <option value="">선택</option>
                      {companies.map((c) => (
                        <option key={c} value={c}>{c}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={instrument.purchase_year}
                      onChange={(e) => handlePurchaseYearUpdate(instrument.id, parseInt(e.target.value))}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      {years.map((year) => (
                        <option key={year} value={year}>{year}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    {instrument.usage_period}년
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={score?.usage_degree_score || 1}
                      onChange={(e) => handleScoreUpdate(instrument.id, 'usage_degree_score', parseInt(e.target.value))}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      {Array.from({ length: 8 }, (_, i) => i + 1).map((n) => (
                        <option key={n} value={n}>{n}시간</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={score?.repair_history_score || 0}
                      onChange={(e) => handleScoreUpdate(instrument.id, 'repair_history_score', parseInt(e.target.value))}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      {[0, 1, 2, 3, 4, 5].map((n) => (
                        <option key={n} value={n}>{n}회</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <button
                      onClick={() => {
                        setSelectedInstrumentForRepair(instrument.id)
                        setShowRepairModal(true)
                      }}
                      className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs"
                    >
                      보기
                    </button>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <select
                      value={instrument.quantity}
                      onChange={(e) => handleQuantityUpdate(instrument.id, parseInt(e.target.value))}
                      className="bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                    >
                      {Array.from({ length: 20 }, (_, i) => i + 1).map((n) => (
                        <option key={n} value={n}>{n}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-2 text-sm">
                    {score ? (
                      (() => {
                        const { status, color } = calculateStatus(
                          instrument.usage_period,
                          score.repair_history_score,
                          score.usage_degree_score
                        )
                        const details = getCalculationDetails(
                          instrument.usage_period,
                          score.repair_history_score,
                          score.usage_degree_score
                        )
                        return (
                          <StatusBadge status={status} color={color} details={details} />
                        )
                      })()
                    ) : (
                      <span className="text-gray-400">미평가</span>
                    )}
                  </td>
                  <td className="px-4 py-2 text-sm">
                    <button
                      onClick={() => setSelectedInstrument(instrument)}
                      className="text-blue-600 hover:underline"
                    >
                      상세
                    </button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        {filteredInstruments.length === 0 && (
          <div className="p-8 text-center text-gray-500">
            일치하는 악기가 없습니다
          </div>
        )}
      </div>

      {/* 모달 */}
      {showAddModal && (
        <AddInstrumentModal
          onClose={() => {
            setShowAddModal(false)
            setSearchQuery('')  // 악기 추가 후 검색 쿼리 초기화
          }}
          onRefresh={fetchData}
        />
      )}
      {selectedInstrument && (
        <InstrumentModal
          instrument={selectedInstrument}
          scores={deteriorationScores.find((s) => s.instrument_id === selectedInstrument.id)}
          onClose={() => setSelectedInstrument(null)}
          onRefresh={fetchData}
        />
      )}
      {showRepairModal && selectedInstrumentForRepair && (
        <RepairHistoryModal
          instrument={instruments.find((i) => i.id === selectedInstrumentForRepair) || null}
          repairHistories={repairHistories.filter((r) => r.instrument_id === selectedInstrumentForRepair)}
          onClose={() => {
            setShowRepairModal(false)
            setSelectedInstrumentForRepair(null)
          }}
          onRefresh={fetchData}
        />
      )}
    </div>
  )
}
