'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import { Instrument, RepairImage } from '@/types'

interface RepairHistory {
  id: string
  instrument_id: string
  repair_date: string
  company_name: string
  cost: number
  repair_content: string
  created_at: string
}

interface RepairHistoryModalProps {
  instrument: Instrument | null
  repairHistories: RepairHistory[]
  onClose: () => void
  onRefresh: () => void
}

export default function RepairHistoryModal({
  instrument,
  repairHistories,
  onClose,
  onRefresh,
}: RepairHistoryModalProps) {
  const [repairDate, setRepairDate] = useState('')
  const [companyName, setCompanyName] = useState('')
  const [cost, setCost] = useState('')
  const [repairContent, setRepairContent] = useState('')
  const [selectedImages, setSelectedImages] = useState<File[]>([])
  const [imagePreviews, setImagePreviews] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [repairImages, setRepairImages] = useState<{ [key: string]: RepairImage[] }>({})
  const [editingRepairId, setEditingRepairId] = useState<string | null>(null)
  const [editRepairDate, setEditRepairDate] = useState('')
  const [editCompanyName, setEditCompanyName] = useState('')
  const [editCost, setEditCost] = useState('')
  const [editRepairContent, setEditRepairContent] = useState('')
  const [editImages, setEditImages] = useState<RepairImage[]>([])
  const [newEditImages, setNewEditImages] = useState<File[]>([])
  const [newEditImagePreviews, setNewEditImagePreviews] = useState<string[]>([])

  if (!instrument) return null

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (selectedImages.length + files.length > 3) {
      alert('최대 3장까지만 선택할 수 있습니다')
      return
    }

    const newFiles = [...selectedImages, ...files.slice(0, 3 - selectedImages.length)]
    setSelectedImages(newFiles)

    // 미리보기 생성
    const previews: string[] = []
    newFiles.forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          previews.push(e.target.result as string)
          if (previews.length === newFiles.length) {
            setImagePreviews(previews)
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const handleRemoveImage = (index: number) => {
    const newFiles = selectedImages.filter((_, i) => i !== index)
    const newPreviews = imagePreviews.filter((_, i) => i !== index)
    setSelectedImages(newFiles)
    setImagePreviews(newPreviews)
  }

  const handleAddRepair = async () => {
    if (!repairDate || !repairContent) {
      alert('수리일자와 수리내용은 필수입니다')
      return
    }

    setIsSubmitting(true)
    try {
      // 수리내역 저장
      const { data: repairData, error: repairError } = await supabase
        .from('repair_history')
        .insert([
          {
            instrument_id: instrument.id,
            repair_date: repairDate,
            company_name: companyName,
            cost: cost ? parseInt(cost) : 0,
            repair_content: repairContent,
          },
        ])
        .select()

      if (repairError) throw repairError
      if (!repairData || repairData.length === 0) throw new Error('Failed to create repair history')

      const repairId = repairData[0].id

      // 이미지 저장
      if (selectedImages.length > 0) {
        const imageRecords = []

        for (let idx = 0; idx < selectedImages.length; idx++) {
          const file = selectedImages[idx]
          const fileName = `${repairId}-${idx}-${Date.now()}`

          // Supabase Storage에 업로드
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('repair_images')
            .upload(`${repairId}/${fileName}`, file)

          if (uploadError) throw uploadError

          // 공개 URL 생성
          const { data: urlData } = supabase.storage
            .from('repair_images')
            .getPublicUrl(`${repairId}/${fileName}`)

          imageRecords.push({
            repair_history_id: repairId,
            image_url: urlData.publicUrl,
            order: idx + 1,
          })
        }

        const { error: imageError } = await supabase
          .from('repair_images')
          .insert(imageRecords)

        if (imageError) throw imageError
      }

      setRepairDate('')
      setCompanyName('')
      setCost('')
      setRepairContent('')
      setSelectedImages([])
      setImagePreviews([])
      await fetchRepairImages()
      onRefresh()
    } catch (error) {
      console.error('Failed to add repair history:', error)
      alert('수리내역 추가에 실패했습니다')
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDeleteRepair = async (repairId: string) => {
    if (!confirm('이 수리내역을 삭제하시겠습니까?')) return

    try {
      // 이미지 먼저 삭제
      await supabase.from('repair_images').delete().eq('repair_history_id', repairId)
      // 수리내역 삭제
      await supabase.from('repair_history').delete().eq('id', repairId)
      onRefresh()
    } catch (error) {
      console.error('Failed to delete repair history:', error)
      alert('수리내역 삭제에 실패했습니다')
    }
  }

  const handleEditRepair = (repair: RepairHistory) => {
    setEditingRepairId(repair.id)
    setEditRepairDate(repair.repair_date)
    setEditCompanyName(repair.company_name)
    setEditCost(repair.cost.toString())
    setEditRepairContent(repair.repair_content)
    setEditImages(repairImages[repair.id] || [])
    setNewEditImages([])
    setNewEditImagePreviews([])
  }

  const handleCancelEdit = () => {
    setEditingRepairId(null)
    setEditRepairDate('')
    setEditCompanyName('')
    setEditCost('')
    setEditRepairContent('')
    setEditImages([])
    setNewEditImages([])
    setNewEditImagePreviews([])
  }

  const handleAddImageForEdit = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (editImages.length + newEditImages.length + files.length > 3) {
      alert('최대 3장까지만 선택할 수 있습니다')
      return
    }

    const newFiles = [
      ...newEditImages,
      ...files.slice(0, 3 - (editImages.length + newEditImages.length)),
    ]
    setNewEditImages(newFiles)

    const previews: string[] = []
    newFiles.forEach((file) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        if (e.target?.result) {
          previews.push(e.target.result as string)
          if (previews.length === newFiles.length) {
            setNewEditImagePreviews(previews)
          }
        }
      }
      reader.readAsDataURL(file)
    })
  }

  const handleRemoveEditImage = (idx: number) => {
    const newFiles = newEditImages.filter((_, i) => i !== idx)
    const newPreviews = newEditImagePreviews.filter((_, i) => i !== idx)
    setNewEditImages(newFiles)
    setNewEditImagePreviews(newPreviews)
  }

  const handleRemoveExistingEditImage = async (imageId: string) => {
    try {
      await supabase.from('repair_images').delete().eq('id', imageId)
      setEditImages(editImages.filter((img) => img.id !== imageId))
    } catch (error) {
      console.error('Failed to delete image:', error)
      alert('이미지 삭제에 실패했습니다')
    }
  }

  const handleSaveEdit = async () => {
    if (!editRepairDate || !editRepairContent) {
      alert('수리일자와 수리내용은 필수입니다')
      return
    }

    setIsSubmitting(true)
    try {
      // 수리내역 업데이트
      await supabase
        .from('repair_history')
        .update({
          repair_date: editRepairDate,
          company_name: editCompanyName,
          cost: editCost ? parseInt(editCost) : 0,
          repair_content: editRepairContent,
        })
        .eq('id', editingRepairId)

      // 새로운 이미지 저장
      if (newEditImages.length > 0) {
        const maxOrder = Math.max(0, ...editImages.map((img) => img.order))
        const imageRecords = []

        for (let idx = 0; idx < newEditImages.length; idx++) {
          const file = newEditImages[idx]
          const fileName = `${editingRepairId}-${maxOrder + idx + 1}-${Date.now()}`

          // Supabase Storage에 업로드
          const { data: uploadData, error: uploadError } = await supabase.storage
            .from('repair_images')
            .upload(`${editingRepairId}/${fileName}`, file)

          if (uploadError) throw uploadError

          // 공개 URL 생성
          const { data: urlData } = supabase.storage
            .from('repair_images')
            .getPublicUrl(`${editingRepairId}/${fileName}`)

          imageRecords.push({
            repair_history_id: editingRepairId,
            image_url: urlData.publicUrl,
            order: maxOrder + idx + 1,
          })
        }

        await supabase.from('repair_images').insert(imageRecords)
      }

      handleCancelEdit()
      await fetchRepairImages()
      onRefresh()
    } catch (error) {
      console.error('Failed to save repair history:', error)
      alert('수리내역 저장에 실패했습니다')
    } finally {
      setIsSubmitting(false)
    }
  }

  const fetchRepairImages = async () => {
    try {
      const { data: imagesData } = await supabase
        .from('repair_images')
        .select('*')
        .order('order', { ascending: true })

      if (imagesData) {
        const grouped: { [key: string]: RepairImage[] } = {}
        imagesData.forEach((img) => {
          if (!grouped[img.repair_history_id]) {
            grouped[img.repair_history_id] = []
          }
          grouped[img.repair_history_id].push(img)
        })
        setRepairImages(grouped)
      }
    } catch (error) {
      console.error('Failed to fetch repair images:', error)
    }
  }

  useEffect(() => {
    fetchRepairImages()
  }, [])

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="flex justify-between items-start mb-6">
          <div>
            <h2 className="text-2xl font-bold text-white mb-2">수리내역</h2>
            <div className="space-y-1 text-sm text-gray-300">
              <p>악기명: <span className="font-semibold">{instrument.name}</span></p>
              <p>카테고리: <span className="font-semibold">{instrument.category}</span></p>
              <p>회사: <span className="font-semibold">{instrument.company}</span></p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white text-2xl"
          >
            ✕
          </button>
        </div>

        {/* 기존 수리내역 */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold text-white mb-4">수리내역 기록</h3>
          {repairHistories.length === 0 ? (
            <div className="text-gray-400 p-4 bg-gray-700 rounded">
              수리내역이 없습니다
            </div>
          ) : (
            <div className="space-y-4">
              {repairHistories.map((repair) => {
                if (editingRepairId === repair.id) {
                  // 편집 모드
                  return (
                    <div key={repair.id} className="bg-blue-900 bg-opacity-40 p-5 rounded-lg border-2 border-blue-500 shadow-lg">
                      <h4 className="text-white font-semibold mb-3">수리내역 수정</h4>
                      <div className="space-y-3">
                        <div>
                          <label className="text-xs text-gray-300">수리일자</label>
                          <input
                            type="date"
                            value={editRepairDate}
                            onChange={(e) => setEditRepairDate(e.target.value)}
                            className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-300">수리회사</label>
                          <input
                            type="text"
                            value={editCompanyName}
                            onChange={(e) => setEditCompanyName(e.target.value)}
                            className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-300">수리비용</label>
                          <input
                            type="number"
                            value={editCost}
                            onChange={(e) => setEditCost(e.target.value)}
                            className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-300">수리내용</label>
                          <textarea
                            value={editRepairContent}
                            onChange={(e) => setEditRepairContent(e.target.value)}
                            rows={3}
                            className="w-full bg-gray-700 text-white border border-gray-600 rounded px-2 py-1 text-xs resize-none"
                          />
                        </div>
                        <div>
                          <label className="text-xs text-gray-300 block mb-2">
                            이미지 ({editImages.length + newEditImages.length} / 3장)
                          </label>
                          {editImages.length > 0 && (
                            <div className="mb-2">
                              <p className="text-xs text-gray-400 mb-1">기존 이미지:</p>
                              <div className="flex gap-2">
                                {editImages.map((img) => (
                                  <div key={img.id} className="relative w-16 h-16 rounded border border-gray-600 overflow-hidden">
                                    <img
                                      src={img.image_url}
                                      alt="edit"
                                      className="w-full h-full object-cover"
                                    />
                                    <button
                                      onClick={() => handleRemoveExistingEditImage(img.id)}
                                      className="absolute top-0 right-0 bg-red-600 text-white w-4 h-4 flex items-center justify-center text-xs hover:bg-red-700"
                                    >
                                      ✕
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          {newEditImagePreviews.length > 0 && (
                            <div className="mb-2">
                              <p className="text-xs text-gray-400 mb-1">새 이미지:</p>
                              <div className="flex gap-2">
                                {newEditImagePreviews.map((preview, idx) => (
                                  <div key={idx} className="relative w-16 h-16 rounded border border-gray-600 overflow-hidden">
                                    <img
                                      src={preview}
                                      alt="new"
                                      className="w-full h-full object-cover"
                                    />
                                    <button
                                      onClick={() => handleRemoveEditImage(idx)}
                                      className="absolute top-0 right-0 bg-red-600 text-white w-4 h-4 flex items-center justify-center text-xs hover:bg-red-700"
                                    >
                                      ✕
                                    </button>
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          <label className="bg-gray-700 hover:bg-gray-600 border border-gray-600 rounded px-3 py-1 text-xs text-white cursor-pointer inline-block">
                            이미지 추가
                            <input
                              type="file"
                              multiple
                              accept="image/*"
                              onChange={handleAddImageForEdit}
                              className="hidden"
                            />
                          </label>
                        </div>
                        <div className="flex gap-2 pt-2">
                          <button
                            onClick={handleSaveEdit}
                            disabled={isSubmitting}
                            className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-3 py-1 rounded text-xs"
                          >
                            저장
                          </button>
                          <button
                            onClick={handleCancelEdit}
                            className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-1 rounded text-xs"
                          >
                            취소
                          </button>
                        </div>
                      </div>
                    </div>
                  )
                }

                // 일반 모드
                return (
                  <div key={repair.id} className="bg-gray-700 rounded-lg border-2 border-gray-500 shadow-md overflow-hidden">
                    {/* 헤더 배경 */}
                    <div className="bg-gray-600 px-5 py-3 border-b border-gray-500">
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="text-white font-bold text-sm">
                            📅 {new Date(repair.repair_date).toLocaleDateString('ko-KR')}
                          </p>
                          {repair.company_name && (
                            <p className="text-xs text-gray-300 mt-1">
                              🏢 {repair.company_name}
                            </p>
                          )}
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => handleEditRepair(repair)}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-2 py-1 rounded text-xs"
                          >
                            수정
                          </button>
                          <button
                            onClick={() => handleDeleteRepair(repair.id)}
                            className="bg-red-600 hover:bg-red-700 text-white px-2 py-1 rounded text-xs"
                          >
                            삭제
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* 본문 */}
                    <div className="p-5">
                      <p className="text-gray-300 text-sm mb-3">
                        <span className="font-semibold text-white">내용:</span> {repair.repair_content}
                      </p>
                      {repair.cost > 0 && (
                        <p className="text-sm text-green-400 font-semibold mb-3">
                          💰 비용: {repair.cost.toLocaleString()}원
                        </p>
                      )}
                      {repairImages[repair.id] && repairImages[repair.id].length > 0 && (
                        <div className="border-t border-gray-600 pt-3 mt-3">
                          <p className="text-xs font-semibold text-gray-300 mb-2">📸 수리 이미지</p>
                          <div className="flex gap-2 flex-wrap">
                            {repairImages[repair.id].map((img, idx) => (
                              <div key={idx} className="w-24 h-24 rounded border-2 border-gray-500 overflow-hidden hover:border-gray-400 transition">
                                <img
                                  src={img.image_url}
                                  alt={`repair-${idx}`}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>

        {/* 새 수리내역 추가 폼 */}
        <div className="border-t border-gray-600 pt-6">
          <h3 className="text-lg font-semibold text-white mb-4">새로운 수리내역 추가</h3>
          <div className="space-y-4">
            {/* 수리일자 */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                수리일자 *
              </label>
              <input
                type="date"
                value={repairDate}
                onChange={(e) => setRepairDate(e.target.value)}
                className="w-full bg-gray-700 text-white border border-gray-600 rounded px-3 py-2 text-sm"
              />
            </div>

            {/* 수리회사 */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                수리회사
              </label>
              <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                placeholder="수리를 담당한 회사명"
                className="w-full bg-gray-700 text-white border border-gray-600 rounded px-3 py-2 text-sm"
              />
            </div>

            {/* 수리비용 */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                수리비용
              </label>
              <input
                type="number"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                placeholder="0"
                className="w-full bg-gray-700 text-white border border-gray-600 rounded px-3 py-2 text-sm"
              />
            </div>

            {/* 수리내용 */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                수리내용 *
              </label>
              <textarea
                value={repairContent}
                onChange={(e) => setRepairContent(e.target.value)}
                placeholder="수리 내용을 입력하세요"
                rows={4}
                className="w-full bg-gray-700 text-white border border-gray-600 rounded px-3 py-2 text-sm resize-none"
              />
            </div>

            {/* 이미지 선택 */}
            <div>
              <label className="block text-sm font-semibold text-gray-300 mb-2">
                이미지 (최대 3장)
              </label>
              <div className="flex items-center gap-3 mb-3">
                <label className="bg-gray-700 hover:bg-gray-600 border border-gray-600 rounded px-4 py-2 text-sm text-white cursor-pointer">
                  선택
                  <input
                    type="file"
                    multiple
                    accept="image/*"
                    onChange={handleImageSelect}
                    className="hidden"
                  />
                </label>
                <span className="text-sm text-gray-400">
                  {selectedImages.length} / 3장
                </span>
              </div>

              {imagePreviews.length > 0 && (
                <div className="flex gap-2">
                  {imagePreviews.map((preview, idx) => (
                    <div key={idx} className="relative w-20 h-20 rounded border border-gray-600 overflow-hidden">
                      <img
                        src={preview}
                        alt={`preview-${idx}`}
                        className="w-full h-full object-cover"
                      />
                      <button
                        onClick={() => handleRemoveImage(idx)}
                        className="absolute top-0 right-0 bg-red-600 text-white w-5 h-5 flex items-center justify-center text-xs hover:bg-red-700"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* 버튼 */}
            <div className="flex gap-3 pt-4">
              <button
                onClick={handleAddRepair}
                disabled={isSubmitting}
                className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 text-white px-4 py-2 rounded text-sm font-semibold"
              >
                {isSubmitting ? '저장 중...' : '수리내역 추가'}
              </button>
              <button
                onClick={onClose}
                className="bg-gray-600 hover:bg-gray-500 text-white px-4 py-2 rounded text-sm"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
