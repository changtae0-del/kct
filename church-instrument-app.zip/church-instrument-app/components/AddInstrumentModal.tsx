'use client'

import { useState } from 'react'
import { supabase } from '@/lib/supabase'
import { Instrument } from '@/types'
import { calculateStatus, getUsagePeriodScore } from '@/lib/deterioration-calc'

interface AddInstrumentModalProps {
  onClose: () => void
  onRefresh: () => void
}

export default function AddInstrumentModal({ onClose, onRefresh }: AddInstrumentModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    category: '타악기' as Instrument['category'],
    model: '',
    company: '',
    purchase_year: new Date().getFullYear(),
    estimated_price: 0,
    usage_period: 0,
    installation_location: '',
    quantity: 1,
  })
  const [scoreData, setScoreData] = useState({
    usage_degree_score: 1,
    repair_history_score: 0,
  })
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [status, setStatus] = useState<any>(null)

  const calculateUsagePeriod = (purchaseYear: number) => {
    const today = new Date()
    const currentYear = today.getFullYear()
    const currentMonth = today.getMonth() // 0-11
    const currentDay = today.getDate() // 1-31

    let basePeriod = currentYear - purchaseYear

    // 현재 월/일을 고려한 소수점 추가
    const decimalPart = (currentMonth + currentDay / 30) / 12
    const totalPeriod = basePeriod + decimalPart

    return Math.max(0, Math.round(totalPeriod))
  }

  const categories: Instrument['category'][] = [
    '타악기',
    '건반악기',
    '현악기',
    '관악기',
    '그외악기',
    '음향관련',
  ]

  const years = Array.from({ length: 26 }, (_, i) => 2026 - i)

  const companies = ['no', 'yamaha', 'nord', 'korg', 'roland', 'pearl', 'tama', 'martin', 'taylor', 'fender', 'efnote', 'vicfirth', 'apple', 'kuzwail']

  const locations = [
    '0 비전홀',
    '1 사랑홀',
    '1 사랑부',
    '2 명지본당',
    '2 새가족실',
    '2 영아부',
    '4 예배학교실',
    '4 홍보실',
    '4 유아부',
    '5 유치부',
    '6 초등1부',
    '8 초등2부',
    '9 세미나',
    '10 초등3부',
    '11 인디',
    '하단본당',
    '하단 격실',
    '기타',
  ]

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setError('')

    try {
      // 악기 저장
      const { data: instrumentData, error: insertError } = await supabase
        .from('instruments')
        .insert([formData])
        .select()

      if (insertError) {
        setError(insertError.message)
        return
      }

      if (!instrumentData || instrumentData.length === 0) {
        setError('악기 저장에 실패했습니다')
        return
      }

      const instrumentId = instrumentData[0].id

      // 상태 계산
      const calculatedStatus = calculateStatus(
        formData.usage_period,
        scoreData.repair_history_score,
        scoreData.usage_degree_score
      )

      // 한글 상태를 영문 enum으로 매핑
      const statusMap: { [key: string]: string } = {
        '유지': 'maintenance',
        '관리': 'continuous_management',
        '교체': 'necessary_replacement',
      }

      // 사용 기간 점수 계산
      const usagePeriodScore = getUsagePeriodScore(formData.usage_period)

      // 총 점수 (백분율 환산: 15점 만점을 100%로)
      const totalPercentage = Math.round((calculatedStatus.totalScore / 15) * 100)

      // 점수 저장
      const { error: scoreError } = await supabase
        .from('deterioration_scores')
        .insert([
          {
            instrument_id: instrumentId,
            purchase_year_score: 5, // 구매연도는 현재 기준으로 5점
            usage_period_score: usagePeriodScore,
            usage_degree_score: scoreData.usage_degree_score,
            repair_history_score: scoreData.repair_history_score,
            total_percentage: totalPercentage,
            status: statusMap[calculatedStatus.status],
            last_updated: new Date().toISOString(),
          },
        ])

      if (scoreError) {
        setError(scoreError.message)
        return
      }

      setStatus(calculatedStatus)
      onRefresh()
      setTimeout(() => onClose(), 1500)
    } catch (err) {
      setError('악기 추가에 실패했습니다')
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-gray-800 rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* 헤더 */}
        <div className="sticky top-0 bg-gray-700 border-b border-gray-600 p-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold">새 악기 추가</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-200 text-2xl"
          >
            ✕
          </button>
        </div>

        {/* 폼 */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-red-900 text-red-100 rounded">
              {error}
            </div>
          )}

          {status && (
            <div className="p-4 bg-green-900 bg-opacity-50 border border-green-600 rounded">
              <p className="text-green-100 font-semibold mb-2">✅ 악기가 저장되었습니다!</p>
              <p className="text-sm text-green-200">상태:
                <span
                  className="ml-2 px-3 py-1 rounded text-white font-semibold"
                  style={{ backgroundColor: status.color }}
                >
                  {status.status}
                </span>
              </p>
              <p className="text-xs text-green-300 mt-2">총점: {status.totalScore}점</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            {/* 악기명 */}
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-2">악기명</label>
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="예: 그랜드 피아노"
              />
            </div>

            {/* 카테고리 */}
            <div>
              <label className="block text-sm font-semibold mb-2">카테고리</label>
              <select
                value={formData.category}
                onChange={(e) => setFormData({ ...formData, category: e.target.value as Instrument['category'] })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {categories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            {/* 수량 */}
            <div>
              <label className="block text-sm font-semibold mb-2">수량</label>
              <input
                type="number"
                min="1"
                value={formData.quantity}
                onChange={(e) => setFormData({ ...formData, quantity: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            {/* 품명 */}
            <div>
              <label className="block text-sm font-semibold mb-2">품명</label>
              <input
                type="text"
                value={formData.model}
                onChange={(e) => setFormData({ ...formData, model: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="예: CFX"
              />
            </div>

            {/* 회사명 */}
            <div>
              <label className="block text-sm font-semibold mb-2">회사명</label>
              <select
                value={formData.company}
                onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">선택</option>
                {companies.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            {/* 구매년도 */}
            <div>
              <label className="block text-sm font-semibold mb-2">구매예상</label>
              <select
                value={formData.purchase_year}
                onChange={(e) => {
                  const year = parseInt(e.target.value)
                  setFormData({
                    ...formData,
                    purchase_year: year,
                    usage_period: calculateUsagePeriod(year)
                  })
                }}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {years.map((year) => (
                  <option key={year} value={year}>
                    {year}
                  </option>
                ))}
              </select>
            </div>

            {/* 단가예상 */}
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-2">단가예상 (₩)</label>
              <div className="space-y-2">
                <input
                  type="range"
                  min="0"
                  max="10000000"
                  step="100000"
                  value={formData.estimated_price}
                  onChange={(e) => setFormData({ ...formData, estimated_price: parseInt(e.target.value) })}
                  className="w-full h-2 bg-gray-600 rounded appearance-none cursor-pointer"
                />
                <div className="text-right text-lg font-semibold text-blue-400">
                  ₩{formData.estimated_price.toLocaleString()}
                </div>
              </div>
            </div>

            {/* 설치위치 */}
            <div className="col-span-2">
              <label className="block text-sm font-semibold mb-2">설치위치</label>
              <select
                value={formData.installation_location}
                onChange={(e) => setFormData({ ...formData, installation_location: e.target.value })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">위치 선택</option>
                {locations.map((location) => (
                  <option key={location} value={location}>
                    {location}
                  </option>
                ))}
              </select>
            </div>

            {/* 구분선 */}
            <div className="col-span-2 border-t border-gray-600 pt-4">
              <h3 className="text-sm font-semibold text-gray-300 mb-4">📊 노후화 평가</h3>
            </div>

            {/* 주당사용 */}
            <div>
              <label className="block text-sm font-semibold mb-2">주당사용 시간</label>
              <select
                value={scoreData.usage_degree_score}
                onChange={(e) => setScoreData({ ...scoreData, usage_degree_score: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {Array.from({ length: 8 }, (_, i) => i + 1).map((n) => (
                  <option key={n} value={n}>{n}시간</option>
                ))}
              </select>
              <p className="text-xs text-gray-400 mt-1">최근 주간 평균 사용 시간</p>
            </div>

            {/* 수리이력 */}
            <div>
              <label className="block text-sm font-semibold mb-2">수리이력</label>
              <select
                value={scoreData.repair_history_score}
                onChange={(e) => setScoreData({ ...scoreData, repair_history_score: parseInt(e.target.value) })}
                className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                {[0, 1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>{n}회</option>
                ))}
              </select>
              <p className="text-xs text-gray-400 mt-1">총 수리 횟수</p>
            </div>
          </div>

          {/* 버튼 */}
          <div className="pt-4 border-t border-gray-700 flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded font-semibold disabled:opacity-50"
            >
              {loading ? '저장 중...' : '저장'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 bg-gray-700 hover:bg-gray-600 text-white py-3 rounded"
            >
              취소
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
