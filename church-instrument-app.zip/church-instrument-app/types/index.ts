// 악기 정보
export type Instrument = {
  id: string
  name: string
  category: '타악기' | '건반악기' | '현악기' | '관악기' | '그외악기' | '음향관련'
  model: string
  company: string
  purchase_year: number
  estimated_price: number
  usage_period: number
  installation_location: string
  quantity: number
  created_at: string
  updated_at: string
}

// 노후화 점수
export type DeteriorationScore = {
  id: string
  instrument_id: string
  purchase_year_score: number // 1-5
  usage_period_score: number // 1-5
  usage_degree_score: number // 1-5
  repair_history_score: number // 1-5
  total_percentage: number // 0-100
  status: 'necessary_replacement' | 'prepare_replacement' | 'middle' | 'continuous_management' | 'maintenance'
  last_updated: string
}

// 수리 이력
export type RepairHistory = {
  id: string
  instrument_id: string
  repair_date: string
  company_name: string
  cost: number
  repair_content: string
  created_at: string
}

// 수리 이력 이미지
export type RepairImage = {
  id: string
  repair_history_id: string
  image_url: string
  order: number
  created_at: string
}

// 정기 점검
export type InspectionSchedule = {
  id: string
  instrument_id: string
  scheduled_date: string
  completed: boolean
  notes: string
}

// 악기 이미지
export type InstrumentImage = {
  id: string
  instrument_id: string
  image_url: string
  order: number
  created_at: string
}

// 상태 텍스트 매핑
export const statusText = {
  necessary_replacement: '필수교체',
  prepare_replacement: '교체준비',
  middle: '중간',
  continuous_management: '지속관리',
  maintenance: '유지',
} as const

// 상태 색상
export const statusColor = {
  necessary_replacement: '#ef4444',
  prepare_replacement: '#f97316',
  middle: '#eab308',
  continuous_management: '#3b82f6',
  maintenance: '#10b981',
} as const
